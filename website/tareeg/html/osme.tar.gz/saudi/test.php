<?php

echo exec("java -jar /var/www/saudi/OSMExtractor.jar test louai@cs.umn.edu road_edges 100 100 0 0 /var/www/saudi/data/ /var/www/saudi/userData/ /var/www/saudi/email/");
?>
