"""distutils

The main package for the Python Module Distribution Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""

__revision__ = "$Id: __init__.py,v 1.22 2001/10/05 20:43:09 theller Exp $"

__version__ = "1.0.3"
