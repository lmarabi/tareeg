<?php

if ($_POST['action']=="coords") {

$type = $_POST['type'];
    switch ($type) {
        case 'Road Network':
            $table = 'road_edges';
            break;
        case 'Lakes':
            $table = 'lake_edges';
            break;
        case 'Rivers':
            $table = 'river_edges';
            break;
        case 'Borders - National\Country':
            $table = 'national_edges';
            break;
        case 'Borders - State\Region\Province':
            $table = 'region_edges';
            break;
        case 'Borders - County\District\Prefectures':
            $table = 'district_edges';
            break;
        case 'Borders - City\Municipality\Town':
            $table = 'city_edges';
            ;break;
        case 'Borders - Neighborhood\Suburb':
            $table = 'neighborhood_edges';
            ;break;
        case 'Borders - All':
            $table = 'border_edges';
            ;break;
        case 'Parks':
            $table = 'park_edges';
            ;break;
        case 'Buildings - Residential':
            $table = 'resident_edges';
            ;break;
        case 'Buildings - Commercial':
            $table = 'commerce_edges';
            ;break;
        case 'Buildings - Services':
            $table = 'services_edges';
            ;break;
        case 'Buildings - Sport':
            $table = 'sport_edges';
            ;break;
        case 'Buildings - Schools':
            $table = 'Education_edges';
            ;break;
        case 'Buildings - Worship':
            $table = 'worship_edges';
            ;break;
        case 'Buildings - All':
            $table = 'building_edges';
            ;break;
	case 'Cemetery':
            $table = 'cemetery_edges';
            ;break;
	case 'desert':
            $table = 'desert_edges';
            ;break;
	case 'Borders - region':
            $table = 'region_edges';
            ;break;
	case 'Borders - district':
            $table = 'district_edges';
            ;break;
	case 'Borders - city':
            $table = 'city_edges';
            ;break;
	case 'Borders - administrative':
            $table = 'administrative_edges';
            ;break;
	case 'Borders - postal':
            $table = 'postal_edges';
            ;break;
	case 'Borders - maritime':
            $table = 'maritime_edges';
            ;break;
	case 'Borders - political':
            $table = 'political_edges';
            ;break;
	case 'Borders - national':
            $table = 'national_edges';
            ;break;
    }

$coords = split(',', $_POST['coords']);
$latmax = $coords[0];
$latmin = $coords[1];
$lonmax = $coords[2];
$lonmin = $coords[3];

$rName = $_POST['rName'];
$rEmail = $_POST['rEmail'];
   

//exec("java -jar /var/www/saudi/OSMExtractor.jar $rName $rEmail $type $latmax $lonmax $latmin $lonmin /var/www/saudi/data/ /var/www/saudi/userData/ /var/www/saudi/email/");

exec("java -jar /var/www/saudi/OSMExtractor.jar test louai@cs.umn.edu road_edges 100 100 0 0 /var/www/saudi/data/ /var/www/saudi/userData/ /var/www/saudi/email/");

//exec("java -jar /home/turtle/Pictures/Test/OSMExtractor.jar test louai@cs.umn.edu $table 100 100 0 0 /home/turtle/Pictures/Test/data/ /home/turtle/Pictures/Test/userData/ /home/turtle/Pictures/Test/email/");
  
 }
?>
